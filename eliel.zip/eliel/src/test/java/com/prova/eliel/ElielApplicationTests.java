package com.prova.eliel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElielApplicationTests {

	@Test
	void contextLoads() {
	}

}
