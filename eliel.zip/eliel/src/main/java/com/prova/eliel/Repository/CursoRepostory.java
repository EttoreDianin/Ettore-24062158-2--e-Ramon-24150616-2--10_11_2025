package com.prova.eliel.Repository;

import com.prova.eliel.Model.Curso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CursoRepostory extends JpaRepository<Curso, Long> {

}
