package com.prova.eliel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElielApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElielApplication.class, args);
	}

}
